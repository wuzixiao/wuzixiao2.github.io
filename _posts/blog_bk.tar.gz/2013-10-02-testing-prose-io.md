---
layout: post
title: "Testing Prose-io"
description: "have a nice try on prose-io"
---

{% include JB/setup %}

## This is just a testing

I have just found this [prose.io](http://prose.io) website for online editing GitPage Blog,
this is just a post for testing.

Pretty cool, it supports the emacs key-binding!

## Work with Jekyll

For the Jekyll blog, you need manully add a line at the meta part.

> layout: post

I haven't found any other good solution.

And also uploading images seems not working, that's a problem really hurt.

## My new gravatar

This will be my new gravatar!

![jobs](/images/jobs.jpg)
